# file: ZipTempDir.rb

require '../chilkat'

# This example discusses the TempDir property.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

zip.OpenZip("exampleData.zip")
zip.AppendOneFileOrDir("ZipStrongEncrypted.rb")

# Important: The methods that write a zip file or exe file do so by
# first writing to a temporary file in a TempDir.  The TempDir property
# defaults to ".", which is the current working directory of the calling
# process.  The reason a temp .zip is first written is to ensure that the
# original .zip (if it exists) is not lost if the WriteZip method fails
# prior to completion.  Only after WriteZip (or WriteExe, WriteZipAndClose, etc.) 
# completes successfully does the existing .zip (or .exe) file get deleted and
# replaced with the new file.  

# Sometimes programs do not have permission to write to the directory pointed to
# by TempDir.  In that case, change the value of TempDir to a directory path where
# the calling process has permission to create a file:
zip.put_TempDir("c:/temp")

zip.WriteZipAndClose()

