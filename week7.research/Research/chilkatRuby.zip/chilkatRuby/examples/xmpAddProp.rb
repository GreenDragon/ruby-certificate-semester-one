# file: xmpAddProp.rb

require '../chilkat'

# Add/replace string properties in XMP metadata
# embedded in a JPG or TIF image file.
xmp = Chilkat::CkXmp.new()
success = xmp.UnlockComponent("Anything for 30-day trial")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

success = xmp.LoadAppFile("images/xmpExample.jpg")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# How many embedded XMP documents in the image file?
numEmbedded = xmp.get_NumEmbedded()
if (numEmbedded == 0) 
	print "This JPG does not have embedded XMP metadata\n"
	exit
end

# Retrieve the 1st XMP document as a CkXml object.
# (There is usually only a single embedded XMP)
xml = xmp.GetEmbedded(0)

# AddSimpleStr adds the string property under the correct 
# rdf:Description subtree.
#
# If the string property already exists, it is replaced,
# otherwise it is added.
# 
# If the rdf:Description subtree does not yet exist for the namespace,
# it is automatically created.  The Chilkat XMP component automatically
# recognizes standard namespaces such as "Iptc4xmpCore" and others
# and will use the correct URI in the rdf:Description node.

xmp.AddSimpleStr(xml,"Iptc4xmpCore:Location","Wheaton")
xmp.AddSimpleStr(xml,"Iptc4xmpCore:CountryCode","US")
xmp.AddSimpleStr(xml,"Iptc4xmpCore:AbcXyz","Junk")

# To use a non-standard namespace, add a namespace mapping:
xmp.AddNsMapping("Chilkat","http:#www.chilkatsoft.com/")

# Chilkat XMP creates an rdf:Description node automatically for the
# "Chilkat" namespace, and the URI used is from our mapping (above).
xmp.AddSimpleStr(xml,"Chilkat:AbcXyz","Junk")

# Save the JPG with its updated XMP metadata.
xmp.SaveAppFile("output/out.jpg")

# Save the XMP to an XML file so we can review the changes in a text editor
xml.SaveXml("output/newXmp.xml")




