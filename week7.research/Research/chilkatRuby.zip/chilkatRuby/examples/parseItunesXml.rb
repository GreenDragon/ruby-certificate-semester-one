# file: parseItunesXml.rb
# 
# Ruby script to parse an iTunes XML document

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

xml = Chilkat::CkXml.new()
xml.LoadXmlFile("c:/temp/itunes.xml")

# Search for this node: <key>Tracks</key>
tracksKey = xml.SearchForContent(xml,"key","Tracks")

# Assuming it's found, the <dict> node is the next sibling
dict = tracksKey.NextSibling()

# Loop over the <dict> child nodes...
n = dict.NumChildrenHavingTag("dict")
for i in 0..(n-1)
	trackRec = dict.GetNthChildWithTag("dict",i)
	print "Name: " + trackRec.GetChildExact("key","Name").NextSibling().content + "\n"
	print "Artist: " + trackRec.GetChildExact("key","Artist").NextSibling().content + "\n"
	print "Time: " + trackRec.GetChildExact("key","Total Time").NextSibling().content + "\n"
end

