# file: TextFormattingTags.rb

require '../chilkat'

# Demonstrates how HTML text formatting tags are (by default) dropped
# during the HTML to XML conversion process.  To keep text formatting
# tags, call UndropTextFormattingTags

htmlConv = Chilkat::CkHtmlToXml.new()
success = htmlConv.UnlockComponent("anything for 30-day trial")
if not success
	print "component is locked!"
	exit
end

html = "<html><body>This <b>is</b> a <i>test</i></body></html>"
	
# To convert, set the HTML and get the XML:
htmlConv.put_Html(html)
xml = htmlConv.xml()
	
print xml


#		The output is this:
#		
#		<?xml version="1.0" encoding="utf-8" ?>
#
#		<root>
#		    <html>
#		        <body>
#		            <text>This  is a  test</text>
#		        </body>
#		    </html>
#		</root>
#		
#		
			
# What happened to the <b> and <i> tags???
# By default, text formatting tags are dropped.
# If we call UndropTextFormattingTags, the tags will remain:
htmlConv.UndropTextFormattingTags()
	
xml = htmlConv.xml()

print xml
	
#		We now get this:
#		
#		<?xml version="1.0" encoding="utf-8" ?>
#
#		<root>
#		    <html>
#		        <body>
#		            <text>This </text>
#		            <b>
#		                <text>is</text>
#		            </b>
#		            <text>a </text>
#		            <i>
#		                <text>test</text>
#		            </i>
#		        </body>
#		    </html>
#		</root>
			

