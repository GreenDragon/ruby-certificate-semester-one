# file: VerifySignedEmail.rb

# Ruby script to verify the signature on a signed email.
#
# This example will load a signed email from a .eml file and demonstrate
# how to determine that the signature is valid.

# (Chilkat email objects can also be created by downloading email from 
# a POP3 server, an IMAP server (using Chilkat IMAP) or loading
# directly from a MIME string.)

# When a Chilkat email object is created, the security layers 
# (signature and/or encryption) are automatically "unwrapped".  
# This happens when an email is loaded from a MIME string, a .eml file, 
# or downloaded from a POP3/IMAP server.

# The result is that your program is always working with an email 
# that is in an unsigned and unencrypted state.  There are properties and
# methods that allow you to determine if the email was originally signed
# and/or encrypted, whether it was successfully verified and/or decrypted,
# and what digital certificates were used.

require '../chilkat'

# Create an instance of the mailman object for unlocking
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Load a digitally signed email from a .eml
email = Chilkat::CkEmail.new()
success = email.LoadEml("signed_email.eml")
if not success
	email.SaveLastError("lastError.txt");
else
	# Was this email signed?
	if (email.get_ReceivedSigned()) then
		print "This email was signed!\n"
		
		# Was the signature verified?  This check is only meaningful if the
		# email was signed (i.e. ReceivedSigned is true)
		if (email.get_SignaturesValid()) then
			print "The digital signature is valid\n"
			
			# Get the digital certificate used for signing.
			cert = email.GetSignedByCert()
			
			# Show the certificate SubjectDN
			subjectDN = Chilkat::CkString.new()
			cert.get_SubjectDN(subjectDN)
			print "certificate SubjectDN:\n  [" + subjectDN.getString() + "]\n"
			
			# Is the certificate valid in all ways?
			if (cert.get_Revoked()) then
				print "Certificate is revoked!\n"
			end
			if (cert.get_Expired()) then
				print "Certificate is expired!\n"
			end
			if (!cert.get_SignatureVerified()) then
				print "Certificate's signature not verified!\n"
			end
			if (!cert.get_TrustedRoot()) then
				print "Certificate's root authority is not trusted!\n"
			end
			
		else
			print "The signature is NOT valid!\n"
		end
	end
end