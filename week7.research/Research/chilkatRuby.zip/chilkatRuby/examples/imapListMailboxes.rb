# file: imapListMailboxes.rb

require '../chilkat'

# Ruby example program to list the mailboxes for a IMAP user account.

imap = Chilkat::CkImap.new()
success = imap.UnlockComponent("anything for 30-day trial")
if not success
	print "imap component is locked!"
	exit
end

# Connect to the IMAP server
success = imap.Connect("mail.chilkatsoft.com")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Login to the IMAP user account.
success = imap.Login("***", "***")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

mboxReference = ""
mboxPattern = "*"
mboxes = imap.ListMailboxes(mboxReference, mboxPattern)

# Loop over the bundle and display the From and Subject.
for i in 0..(mboxes.get_Count-1)
    print mboxes.getName(i) + "\n"
end

# Disconnect from the IMAP server.
imap.Disconnect()
