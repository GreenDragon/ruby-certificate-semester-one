# file: xmpCopy.rb

require '../chilkat'

# Copy XMP metadata from one JPG to another.
xmp = Chilkat::CkXmp.new()
success = xmp.UnlockComponent("Anything for 30-day trial")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# Load a JPG containing XMP metadata.
success = xmp.LoadAppFile("images/xmpExample.jpg")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# Load a JPG that does not contain XMP metadata.
xmp2 = Chilkat::CkXmp.new()
success = xmp2.LoadAppFile("images/starfish.jpg")
if not success
	xmp2.SaveLastError("errorLog.txt")
	exit
end

# How many embedded XMP documents in the image file?
numEmbedded = xmp.get_NumEmbedded()
if (numEmbedded == 0) 
	print "This JPG does not have embedded XMP metadata\n"
	exit
end

# Retrieve the 1st XMP document as a CkXml object.
# (There is usually only a single embedded XMP)
xml = xmp.GetEmbedded(0)

# Add it to starfish.jpg
# (The JPG file is not updated until SaveAppFile is called.)
xmp2.Append(xml)

# Save it.
xmp2.SaveAppFile("output/starfish.jpg")




