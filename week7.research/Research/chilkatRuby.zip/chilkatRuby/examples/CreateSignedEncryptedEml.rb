# file: CreateSignedEncryptedEml.rb

require '../chilkat'

# How to create a .eml file that is both digitally signed and encrypted.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Create a simple email
email = Chilkat::CkEmail.new()
email.put_Subject("Signed + encrypted email in Ruby")
email.put_Body("Signed + encrypted email in Ruby")
email.put_From("Chilkat Support <support@chilkatsoft.com>")
email.AddTo("TagTooga","admin@tagtooga.com")

# Simply indicate that the email is to be signed AND encrypted:
email.put_SendEncrypted(true)
email.put_SendSigned(true)

mimeStr = Chilkat::CkString.new()
# The RenderToMime method renders the email according to the property settings
# of the email and mailman objects.
success = mailman.RenderToMime(email,mimeStr)
if not success
	mailman.SaveLastError("lastError.txt");
else
	# Convert line endings from CRLF to bare LF's
	mimeStr.toLF()
	# Save the MIME string to a file.
	aFile = File.new("secure_email.eml", "w")
	aFile.write(mimeStr.getString())
	aFile.close
end
