# file: mimeTraverse.rb

require '../chilkat'

def traverseMime(mime, level)

	line = ""
		
	for i in 0..level-1
		line = line + "----"
	end
	
	line = line + mime.contentType
		
	print line + "\n"
		
	n = mime.get_NumParts()
	for i in 0..n-1
		part = mime.GetPart(i)
		traverseMime(part,level+1)
	end

end

# This example builds a complex email:
# -- one that has both plain-text and HTML alternative bodies.
# -- the HTML has embedded images
# -- there are multiple attachments.
# We then examine the MIME structure using Chilkat MIME.
		
# First, we'll need the email component unlocked...
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# We'll convert a web page into an email with embedded
# images.
mht = Chilkat::CkMht.new()
mht.UnlockComponent("anything for 30-day trial")
		
# Our URL was picked at random...
email = mht.GetEmail("http://www.masukolandscaping.com/")
		
# Add a plain-text alternative body.
email.AddPlainTextAlternativeBody("this is the plain-text alternative...")
		
# Add a few file attachments:
strContentType = Chilkat::CkString.new()
# AddFileAttachment returns the auto-selected content-type in strContentType
email.AddFileAttachment("images/dudeRuby.gif",strContentType)
email.AddFileAttachment("blah.txt",strContentType)
		
# Now we have a complex email.  Get it as a MIME object and examine
# the structure...
mime = Chilkat::CkMime.new()
mime.UnlockComponent("anything for 30-day trial")
		
mime = email.GetMimeObject();	
mime.SaveMime("e.eml")
		
traverseMime(mime,0)
		
# Prints this:

# multipart/mixed
# ----multipart/related
# --------multipart/alternative
# ------------text/plain
# ------------text/html
# --------image/gif
# --------image/gif
# --------image/gif
# --------image/gif
# --------image/gif
# --------image/gif
# --------image/jpeg
# --------image/gif
# --------image/gif
# --------image/gif
# --------image/gif
# --------image/gif
# ----image/gif
# ----text/plain

