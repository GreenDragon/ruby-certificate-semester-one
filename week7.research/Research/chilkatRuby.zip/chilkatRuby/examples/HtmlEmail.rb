# file: HtmlEmail.rb

# Ruby script to send an HTML email using CkMht to help
# A sample .html file with four images and a style sheet
# has been pre-made for this example (testEmail.html).
# The images are located in the "images" subdirectory,
# and the CSS file is found in the "css" subdirectory.
# The CkMht class can load the HTML file and return
# a CkEmail object with all external (related) items 
# embedded (i.e. style sheets and images).

require '../chilkat'

# How to send HTML email in Ruby using the Chilkat mail module
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a login, set username/password
# mailman.put_SmtpUsername("myUsername")
# mailman.put_SmtpPassword("myPassword")

# The Chilkat MHT object is needed to convert an HTML file to an HTML email.
mht = Chilkat::CkMht.new()
mht.UnlockComponent("anything for 30-day trial")

# Create the HTML mail
email = mht.GetEmail("testEmail.html")

# Don't forget the subject and From/To ..
email.put_Subject("Sending HTML email from Ruby")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

# Send the HTML e-mail...
success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end

