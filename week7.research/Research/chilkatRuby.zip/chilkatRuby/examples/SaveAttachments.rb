# file: SaveAttachments.rb

# Ruby script to save email attachments.

require '../chilkat'

# Create an instance of the mailman object for reading POP3 email.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Create an email object and load it with a .eml file.
email = Chilkat::CkEmail.new()
email.LoadEml("testEmail.eml")

# Save all attachments to a relative subdirectory named "attachments"
# The directory is automatically created if it does not yet exist.
email.SaveAllAttachments("attachments")
# Save all attachments to an absolute directory named "/temp/attachments"
# The directory is automatically created if it does not yet exist.
email.SaveAllAttachments("/temp/attachments")

# The email.OverwriteExisting property controls whether existing files
# are overwritten if attachments have the same filename.  This property
# is true by default.  If set to false, the attachment filename(s) will
# be modified if there is a conflict.
email.put_OverwriteExisting(false)

# Attachments may also be saved individually:
numAttach = email.get_NumAttachments()
filename = Chilkat::CkString.new()
for j in 0..(numAttach-1)
	email.GetAttachmentFilename(j,filename)
	fileSize = email.GetAttachmentSize(j)
	print "Before saving: " + filename.getUtf8() + ", " + fileSize.to_s() + " bytes\n"
	# Save the Nth attachment.  Because OverwriteExisting = false, and the attachments
	# were previously saved to the same subdirectory by SaveAllAttachments, each
	# attachment filename is automatically modified to prevent ovewriting existing files.
	# The actual filename saved is available by calling GetAttachmentFilename after saving.
	email.SaveAttachedFile(j,"attachments")
	email.GetAttachmentFilename(j,filename)
	print "After saving: " + filename.getUtf8() + ", " + fileSize.to_s() + " bytes\n"
end

