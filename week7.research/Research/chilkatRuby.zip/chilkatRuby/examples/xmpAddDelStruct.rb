# file: xmpAddDelStruct.rb

require '../chilkat'

# Add and delete fields within structure properties.
xmp = Chilkat::CkXmp.new()
success = xmp.UnlockComponent("Anything for 30-day trial")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

success = xmp.LoadAppFile("images/xmpExample.jpg")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# How many embedded XMP documents in the image file?
numEmbedded = xmp.get_NumEmbedded()
if (numEmbedded == 0) 
	print "This JPG does not have embedded XMP metadata\n"
	exit
end

# Retrieve the 1st XMP document as a CkXml object.
# (There is usually only a single embedded XMP)
xml = xmp.GetEmbedded(0)

# Remove the Iptc4xmpCore:CiEmailWork in the Iptc4xmpCore:CreatorContactInfo structure.
xmp.RemoveStructProp(xml,"Iptc4xmpCore:CreatorContactInfo","Iptc4xmpCore:CiEmailWork")

# AddStructProp updates the property value if it already exists.
xmp.AddStructProp(xml,"Iptc4xmpCore:CreatorContactInfo","Iptc4xmpCore:CiAdrCity","Chicago")

# Add if does not already exist:
xmp.AddStructProp(xml,"Iptc4xmpCore:CreatorContactInfo","Iptc4xmpCore:Comments","Hello World!")

# Create entirely new structure w/ 1st member if the structure does not yet exist.
xmp.AddStructProp(xml,"Iptc4xmpCore:MyCustumStruct","AbcXyz","1234")

# Save the JPG with its updated XMP metadata.
xmp.SaveAppFile("output/out.jpg")

# Save the XMP to an XML file so we can review the changes in a text editor
xml.SaveXml("output/modifiedXmp.xml")



