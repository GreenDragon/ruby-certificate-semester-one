# file: MultipleRecipients.rb

require '../chilkat'

# Demonstrate how to add multiple To, CC, and BCC recipients
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a authentication, set username/password
#mailman.put_SmtpUsername("***")
#mailman.put_SmtpPassword("***")

# Create an e-mail object
email = Chilkat::CkEmail.new()
email.put_Subject("Send email in Ruby to multiple recipients")
email.put_Body("Email with multiple recipients (To, CC, BCC)")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Call AddTo, AddCC, and AddBCC multiple times, one for each recipient
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

email.AddCC("John","john@chilkatsoft.com")
email.AddCC("Joe","joe@chilkatsoft.com")

# BCC header fields do not appear in the MIME source of the email.
# they are only delivered to the SMTP server in the form of "RCPT TO" commands
# during the mail sending.  Therefore, "To" and "CC" recipients cannot possibly
# know about the BCC recipients.
email.AddBcc("TagTooga Support","support@tagtooga.com")
email.AddBcc("Jim","jim@tagtooga.com")

# Your program may clear recipients by calling ClearTo, ClearCC, or ClearBcc
# These will be commented out in this example:
#email.ClearTo()
#email.ClearCC()
#email.ClearBcc()

# Send the email
success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
