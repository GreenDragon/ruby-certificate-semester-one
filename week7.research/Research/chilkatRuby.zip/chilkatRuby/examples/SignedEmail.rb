# file: SignedEmail.rb

require '../chilkat'

# How to send digitally signed email in Ruby
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a login, set username/password
# mailman.put_SmtpUsername("myUsername")
# mailman.put_SmtpPassword("myPassword")

# Create a simple email
email = Chilkat::CkEmail.new()
email.put_Subject("Sending signed email from Ruby")
email.put_Body("This signed email was sent from a Ruby script")
# The signature uses the digital certificate of the sender (i.e. the email
# address in the FROM header field).
email.put_From("TagTooga <admin@tagtooga.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("Support","support@chilkatsoft.com")

# There are a number of ways to send digitally signed email using Chilkat.
# This example demonstrates the easiest (other examples will explore
# some of the other possibilities).
# To send a signed email, the digital certificate matching the sender's email
# address (in the FROM header field) should have been previously be installed on your computer
# with the private key.  
# If not, you may install from a .pfx (or .p12) file.
# Double-click on the .pfx to install.  Do not check the "Enable strong private key
# protection" checkbox because if you do, programs that access the private key
# will cause the operating system to display a pop-up warning dialog to 
# notify the logged-in user of the private key access.  Otherwise, select all the
# defaults and import the certificate.
# 
# IMPORTANT: The .pfx should be imported from the same logged-in account
# under which the program will be running.  This is because private keys
# are stored by Windows within the logged-on user's "protected store".
#
# Once the PFX is installed, the Chilkat component should be able to locate
# the certificate for signing.  You only need to set the SendSigned property = true:
email.put_SendSigned(true)
    
success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
