# file: ZipToMemory.rb

require '../chilkat'

# Zip a directory tree, but instead of creating a .zip file,
# write the zip to a buffer in memory.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

zip.NewZip("exampleData.zip")
zip.AppendFiles("exampleData/*",true)

zipFileImage = Chilkat::CkByteData.new()
zip.WriteToMemory(zipFileImage)

# What's the point of this?
# Other Chilkat components can work with CkByteData objects.
# For example, we could add the Zip to a MIME message...
mime = Chilkat::CkMime.new()
mime.UnlockComponent("Anything for 30-day trial")
mime.put_ContentType("application/zip")
mime.SetBodyFromBinary(zipFileImage)
mime.SaveMime("mime.txt")

# Or.. you could upload the zip file to
# an FTP server without ever having to write
# an actual .zip on the local filesystem...
ftp = Chilkat::CkFtp2.new()
ftp.UnlockComponent("anything for 30-day trial")
ftp.put_Hostname("www.chilkatsoft.com")
ftp.put_Username("myLogin")
ftp.put_Password("myPassword")
success = ftp.Connect()
if (success)
	ftp.ChangeRemoteDir("d2")
	remoteFilename = "myZip.zip"
	success = ftp.PutFileFromBinaryData(remoteFilename,zipFileImage)
	if (success)
		printf("Uploaded Zip to FTP server!\n")
	else
		ftp.SaveLastError("ftpPutError.txt")
	end
else
	ftp.SaveLastError("ftpError.txt")
end