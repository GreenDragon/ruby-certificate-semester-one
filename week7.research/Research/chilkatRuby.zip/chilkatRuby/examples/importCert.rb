# file: importCert.rb

require '../chilkat'

# Import a certificate from a .cer file to the current-user certificate store.
# The Current User cert store is located in the Windows registry and is specific
# to the logged-on user of the calling process.  .cer files do not contain private
# keys.  Therefore, certificates imported in this way can only be used for
# verifying signatures or encrypting data. (Not for creating signatures or
# decrypting data.)

# The CkCert, CkCertStore, and CkCreateCS are free utility classes that can be 
# used in any Ruby application/script without the need to purchase a license.

ccs = Chilkat::CkCreateCS.new()

# Open the current-user certificate store in read/write mode.
ccs.put_ReadOnly(false)
certStore = ccs.OpenCurrentUserStore()

if certStore == nil
	ccs.SaveLastError("lastError.txt");
	print "Failed to open current user certificate store\n"
else
	cert = Chilkat::CkCert.new()
	success = cert.LoadFromFile("tagtooga.cer")
	if success
		success = certStore.AddCertificate(cert)
		if success
			print "Added certificate to certificate store!\n"
		else
			certStore.SaveLastError("lastError.txt");
			print "Failed to add certificate to cert store\n"
		end
	else
		cert.SaveLastError("lastError.txt");
		print "Failed to load .cer file\n"
	end	
end
