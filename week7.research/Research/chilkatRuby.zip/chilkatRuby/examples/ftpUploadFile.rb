# file: ftpUploadFile.rb

require '../chilkat'

# Ruby script to upload a file to an FTP server.

ftp = Chilkat::CkFtp2.new()
success = ftp.UnlockComponent("anything for 30-day trial")
if not success
	print "ftp component is locked!"
	exit
end

ftp.put_Username("***")
ftp.put_Password("***")
ftp.put_Hostname("blog.chilkatsoft.com")

# Connect to the FTP server
success = ftp.Connect()
if not success
	ftp.SaveLastError("errorLog.txt")
	exit
end

# Set our remote directory to "ftpTest"
success = ftp.ChangeRemoteDir("ftpTest")
if not success
	ftp.SaveLastError("errorLog.txt")
	exit
end

# Upload a file.
localFile = "images/dude.gif"
remoteFile = "dude.gif"
success = ftp.PutFile(localFile,remoteFile)
if not success
	ftp.SaveLastError("errorLog.txt")
	exit
end

# Disconnect from the FTP server.
ftp.Disconnect()

print "FTP Upload Successful!\n"
