# file: ZipStrongEncrypted.rb

require '../chilkat'

# Demonstrates how to create a WinZip-compatible 128-bit AES strong encrypted zip
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

zip.NewZip("strongEncrypted.zip")

# Set the Encryption property = 4, which indicates WinZip compatible AES encryption.
zip.put_Encryption(4)
# The key length can be 128, 192, or 256.
zip.put_EncryptKeyLength(128)
zip.SetPassword("secret")

zip.AppendFiles("exampleData/*",true)
zip.WriteZip()

