# file: SendEmail.rb

require '../chilkat'

# How to send email in Ruby using the Chilkat Email Ruby module
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a login, set username/password
# mailman.put_SmtpUsername("myUsername")
# mailman.put_SmtpPassword("myPassword")

# Create a simple email
email = Chilkat::CkEmail.new()
email.put_Subject("Sending email from Ruby")
email.put_Body("This email was sent from a Ruby script")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
