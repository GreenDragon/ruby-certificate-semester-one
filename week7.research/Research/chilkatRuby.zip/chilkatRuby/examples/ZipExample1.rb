# file: ZipExample1.rb

require '../chilkat'

# Simple example showing how to Zip a directory tree
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

zip.NewZip("exampleData.zip")
zip.AppendFiles("exampleData/*",true)
zip.WriteZip()

