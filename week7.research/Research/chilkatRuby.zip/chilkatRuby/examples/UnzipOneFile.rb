# file: UnzipOneFile.rb

require '../chilkat'

# Unzip a single file contained within a Zip archive.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

# Open an already-existing zip
success = zip.OpenZip("exampleData.zip")
if success
	# Locate the file to be unzipped.
	# The zip in this example contains these files and directories:
	# exampleData\
	# exampleData\hamlet.xml
	# exampleData\123\
	# exampleData\aaa\
	# exampleData\123\hello.txt
	# exampleData\aaa\banner.gif
	# exampleData\aaa\dude.gif
	# exampleData\aaa\xyz\	
	
	# When passing directory paths, either forward and backward slashes can be used.
	zipEntry = zip.FirstMatchingEntry("*aaa/dude.gif")
	if (zipEntry != nil) 
		# Extract dude.gif into the images subdirectory regardless of the
		# path included with the entry within the zip.
		zipEntry.ExtractInto("images")
		
		# If we called "Extract" like this:
		zipEntry.Extract("images")
		# the component would create dude.gif in "images/exampleData/aaa"
	else
		# Failed to find the file.
		zip.SaveLastError("findMatchingEntryLog.txt")
	end		
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end
