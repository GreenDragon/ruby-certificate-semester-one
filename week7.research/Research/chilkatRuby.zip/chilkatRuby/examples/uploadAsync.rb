# file: uploadAsync.rb

require '../chilkat'

# Asynchronous HTTP Upload Ruby Script
# Uploads one or more files to a web server over HTTP.
upload = Chilkat::CkUpload.new()

# Set our idle timeout to 30 seconds (30000 millisec).
# If progress halts for more than this time, the upload
# is automatically aborted.
upload.put_IdleTimeoutMs(30000)

# Set the ChunkSize.  The ChunkSize can help with performance.
# It is the size, in bytes, of each TCP socket write during
# the upload.
upload.put_ChunkSize(2048)

# Set the target for the upload.
# This example tests against http://freeaspupload.net
upload.put_Hostname("www.freeaspupload.net")
upload.put_Port(80)
upload.put_Path("/freeaspupload/testUpload.asp")

# Add some files to be uploaded...

# The AddFileReference method does not read the files into
# memory.  It simply adds a reference within the CkUpload
# object so that the file is included when upload is initiated.

# The 1st argument is the name that would be in an HTML input
# tag, such as this:
# <input name=attach1 type=file size=20>

# The 2nd argument is an existing file on disk.  The filepath,
# if included, may be absolute or relative to the current working
# directory.
upload.AddFileReference("attach1", "c:\\temp\\hamlet.xml")

# Multiple files may be uploaded at once by calling
# AddFileReference multiple times.
# upload.AddFileReference "attach2", "c:\temp\a\dudeA.gif"
# upload.AddFileReference "attach3", "c:\temp\a\hello.txt"
# upload.AddFileReference "attach4", "c:\temp\hamlet.xml"

# Start an asynchronous upload in a background thread.
upload.BeginUpload()

# Wait for the upload to complete.  Your application might do other
# useful tasks rather than simply waiting...
while (upload.get_UploadInProgress())
    # Sleep a short time (.1 seconds)
    upload.SleepMs(100)
    
    # During the upload, the application can access three progress
	# indicators:

	# (1) The total upload size:
	# If the upload just started, this may still be zero.  It will change
	# to the total upload size (in bytes) once the sizes of all the files
	# to be uploaded have been collected.
	totalBytes = upload.get_TotalUploadSize()

	# Note: Files are uploaded in streaming mode. What that means for your
	# application is that the memory footprint is small and constant.  The
	# entire file is not loaded into memory at once.

	# (2) The number of bytes uploaded so far:
	bytesUploaded = upload.get_NumBytesSent()

	# (3) The percentage completed (a value from 0 to 100)
	percentComplete = upload.get_PercentUploaded()
	    
    # The application may also abort an upload at any point by calling
	# the AbortUpload method:
	# We'll leave it commented out....
	#upload.AbortUpload()
    
end

# The loop exits when the upload is finished, aborted, or failed.
# Now check to see if it succeeded:
if (upload.get_UploadSuccess())
    # The upload was a success in that the HTTP upload was sent
    # and we received an HTTP response.  You may wish to check
    # the HTTP response to ensure that it is what you expect.
    
    # The HTTP response status code (i.e. 200, 404, etc.) is available
    # in the ResponseStatus property:
    if (upload.get_ResponseStatus() != 200) 

        upload.SaveLastError("output/uploadError.xml")
        
        printf("Failed to upload, HTTP response code = %d\n",upload.get_ResponseStatus())
	else
	    # We have a valid 200 response.
	    
	    # Display the response header:
	    printf("HTTP response header:\n%s\n----\n",upload.responseHeader())
	        
	    # Get the response body.
		body = Chilkat::CkByteData.new()
	    upload.get_ResponseBody(body)
		
	    html = body.to_s()
	    printf("HTTP response body:\n%s\n----\n",html)

	    # If the upload succeeded, we will find this string in the HTML:
	    if (html.index("Upload completed") > 0) 
			printf("Upload successful!\n")
	    else
	        # An unexpected response was received.
	        printf("Unexpected HTML response!\n")
		end
	end
else
    # save the last-error information to a file:
    upload.SaveLastError("output/uploadError.xml")
end
