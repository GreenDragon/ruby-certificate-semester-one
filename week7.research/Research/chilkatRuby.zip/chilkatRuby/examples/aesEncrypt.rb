# file: aesEncrypt.rb

require '../chilkat'

# Ruby AES Encryption Example Script
crypt = Chilkat::CkCrypt2.new()
crypt.UnlockComponent("anything for 30-day trial")
    
crypt.put_CryptAlgorithm("aes")
# Use cipher block chaining (CBC) mode
crypt.put_CipherMode("cbc")
# Use 128-bit encryption
crypt.put_KeyLength(128)
# Set the initialization vector.
crypt.SetEncodedIV("000102030405060708090A0B0C0D0E0F","hex")
# Set the secret key.
crypt.SetEncodedKey("000102030405060708090A0B0C0D0E0F","hex")
# Encoding the encrypted bytes in base64
crypt.put_EncodingMode("base64")
# Use the default padding scheme (PKCS5 Padding)
crypt.put_PaddingScheme(0)

encryptedStr = Chilkat::CkString.new()
crypt.EncryptStringENC("Hello World!",encryptedStr)

# Output is: qiq+IFhcjTkEIkZyf31V/g==
print "Encrypted: " + encryptedStr.getString() + "\n"

decryptedStr = Chilkat::CkString.new()
crypt.DecryptStringENC(encryptedStr.getString(),decryptedStr)

print "Decrypted: " + decryptedStr.getString() + "\n"

