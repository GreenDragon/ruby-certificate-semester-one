# file: convertFileCharset.rb

require '../chilkat'

# (The CkString class is freeware)
# Load a utf-8 file and save it as windows-1252.
fileContents = Chilkat::CkString.new()

# Load a file into the object.  The charset is explicitly
# named so the CkString object can properly interpret the encoding.
fileContents.loadFile("exampleData/utf8.html","utf-8")

# Save the file as windows-1252
fileContents.saveToFile("exampleData/windows1252.html","windows-1252")

# Note: This does not edit the HTML to change the HTML META tag indicating
# charset.  Some text editors (such as EmEditor) may be aware of the tag and
# attempt to interpret the bytes according to the encoding indicated by the META tag.

# More information about CkString can be found here:
# http://www.chilkatsoft.com/refdoc/rubyCkStringRef.html
# http://www.example-code.com/ruby/ruby-string-processing.asp

# Any of the following charsets can be used:
# us-ascii
# unicode
# unicodefffe
# iso-8859-1
# iso-8859-2
# iso-8859-3
# iso-8859-4
# iso-8859-5
# iso-8859-6
# iso-8859-7
# iso-8859-8
# iso-8859-9
# iso-8859-13
# iso-8859-15
# windows-874
# windows-1250
# windows-1251
# windows-1252
# windows-1253
# windows-1254
# windows-1255
# windows-1256
# windows-1257
# windows-1258
# utf-7
# utf-8
# utf-32
# utf-32be
# shift_jis
# gb2312
# ks_c_5601-1987
# big5
# iso-2022-jp
# iso-2022-kr
# euc-jp
# euc-kr
# macintosh
# x-mac-japanese
# x-mac-chinesetrad
# x-mac-korean
# x-mac-arabic
# x-mac-hebrew
# x-mac-greek
# x-mac-cyrillic
# x-mac-chinesesimp
# x-mac-romanian
# x-mac-ukrainian
# x-mac-thai
# x-mac-ce
# x-mac-icelandic
# x-mac-turkish
# x-mac-croatian
# asmo-708
# dos-720
# dos-862
# ibm037
# ibm437
# ibm500
# ibm737
# ibm775
# ibm850
# ibm852
# ibm855
# ibm857
# ibm00858
# ibm860
# ibm861
# ibm863
# ibm864
# ibm865
# cp866
# ibm869
# ibm870
# cp875
# koi8-r
# koi8-u


# The CkCharset object provides more sophisticated charset conversion,
# with different failure options when non-convertable data is encountered.
# It also provides HTML conversion capabilities such that the HTML META tag
# indicating the charset is also updated:
# Unfortunately, the CkCharset object is not freeware.
cc = Chilkat::CkCharset.new()
cc.UnlockComponent("anything for 30-day trial")
cc.put_ToCharset("windows-1252")
cc.put_FromCharset("utf-8")
cc.ConvertHtmlFile("exampleData/utf8.html","exampleData/out2.html")

