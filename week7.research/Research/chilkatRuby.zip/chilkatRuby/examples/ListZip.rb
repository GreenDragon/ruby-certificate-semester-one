# file: ListZip.rb

require '../chilkat'

# Simple example showing how to list the files and directories within a Zip archive.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

filename = Chilkat::CkString.new()

success = zip.OpenZip("exampleData.zip")
if success
	# Iterate over the files and directories within the Zip, printing the filename
	# and/or directory path of each.
	entry = zip.FirstEntry()
	while entry != nil
		entry.get_FileName(filename)
		print filename.getString() + "\n"
		entry = entry.NextEntry()
	end
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end

