# file: AddToZip.rb

require '../chilkat'

# Add a single file to an existing zip.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

# Open an already-existing zip
success = zip.OpenZip("exampleData.zip")
if success
	# Append an additional file to the zip.
	success = zip.AppendOneFileOrDir("blowfishCBC.rb")
	if (success) 
		# Write the zip.
		zip.WriteZip()
	else
		# Failed to append the file.
		zip.SaveLastError("appendError.txt")
	end		
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end
