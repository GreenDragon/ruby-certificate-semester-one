# file: AesEncryptString.rb

require '../chilkat'

# Ruby AES String Encryption
    
crypt = Chilkat::CkCrypt2.new()
crypt.UnlockComponent("anything for 30-day trial")
    
# Tell the encryptor what encryption algorithm to use.
# Rijndael is a synonym for "AES".
crypt.put_CryptAlgorithm("aes")

# Set the cipher mode to cbc (this is the default).  The other cipher mode is "ecb".
crypt.put_CipherMode("cbc")

# The key length can be 128-bits, 192-bits, or 256-bits.
crypt.put_KeyLength(128)
    
# Padding Schemes:
# 0((RFC2630) Each padding byte is the pad count (16 extra added if size is already a multiple of 16)
# 1(Random bytes except the last is the pad count (16 extra added if size is already multiple of 16)
# 2(Pad with random data. (If already a multiple of 16, no padding is added).
# 3(Pad with NULLs. (If already a multiple of 16, no padding is added).
# 4(Pad with SPACE chars(0x20). (If already a multiple of 16, no padding is added).
crypt.put_PaddingScheme(4)
    
# Set the 16-byte initialization vector via a hex encoded string.
# If the IV is not set, it defaults to all '\0' bytes.
crypt.SetEncodedIV("000102030405060708090A0B0C0D0E0F", "hex")
    
# Set our secret key.  To do this, we hash a password string to a binary secret key
# having the correct bit length (equal to the key length).
keyData = Chilkat::CkByteData.new()
crypt.GenerateSecretKey("This is my password string",keyData)
crypt.put_SecretKey(keyData)
    
# Encrypt a string, returning the encrypted data as a hex encoded string.
crypt.put_EncodingMode("hex")

encryptedHexString = Chilkat::CkString.new()
crypt.EncryptStringENC("ABCDEFGHIJKLMNOPQRSTUVWXYZ",encryptedHexString)

# The AES algorithm pads to a 16-byte multiple.  In this example, the 26-byte
# input string is padded to 32 bytes with SPACE characters and encrypted.
# The result is a 64-byte hex string (2 characters per binary byte)
printf("%d, %s\n",encryptedHexString.getNumChars(),encryptedHexString.getString())

# Decrypting is easy...
decryptedString = Chilkat::CkString.new()
crypt.DecryptStringENC(encryptedHexString.getString(),decryptedString)
# Trim the SPACE characters added as padding...
decryptedString.trim()
printf("Decrypted: [%s]\n",decryptedString.getString())