# file: SmtpSsl.rb

# Ruby script to send email over an SSL secure connection.

# Connects to an SMTP server via SSL and sends mail.
# The default non-secure port for SMTP servers is 25.
# Usually, the SMTP SSL port is 465.  To send e-mail over
# SSL, it's as simple as setting two properties prior to sending:
	
# 1) Set the SmtpSsl property = true to indicate that you want SSL.
# 2) Set the SmtpPort property = 465

# Note: When sending email over an SSL connection, *everything* is protected.
# If authentication is required, your login/password is sent securely.  
# The entire email, including attachments, is sent over SSL.

require '../chilkat'

# Create an instance of the mailman object for sending.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# Set SSL properties:
mailman.put_SmtpPort(465)
mailman.put_SmtpSsl(true)

# If your SMTP server requires a login, set username/password
mailman.put_SmtpUsername("myLogin")
mailman.put_SmtpPassword("myPassword")

# Create a simple email
email = Chilkat::CkEmail.new()
email.put_Subject("SMTP SSL Ruby Scripting Example")
email.put_Body("This email was sent over SSL from a Ruby script")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
