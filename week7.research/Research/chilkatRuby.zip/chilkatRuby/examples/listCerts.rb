# file: listCerts.rb

require '../chilkat'

# List digital certificates in the Windows registry stores:
# List the certs in the Current User Store,
# then list the certs in the Local Machine Certificate Store.

# The CkCert, CkCertStore, and CkCreateCS are free utility classes that can be 
# used in any Ruby application/script without the need to purchase a license.

ccs = Chilkat::CkCreateCS.new()

# Open the current-user certificate store in read-only mode.
ccs.put_ReadOnly(true)
certStore = ccs.OpenCurrentUserStore()

if certStore == nil
	ccs.SaveLastError("lastError.txt");
	print "Failed to open current user certificate store\n"
else
	print "Current User Digital Certificates:\n"
	n = certStore.get_NumCertificates()
	for i in 0 .. n-1
		cert = certStore.GetCertificate(i)
		# Print the common name of the certificate.
		print "CN: " + cert.subjectCN + "\n"
	end	
end
print "\n"

# Open the local-machine certificate store in read-only mode.
certStore = ccs.OpenLocalSystemStore()

if certStore == nil
	ccs.SaveLastError("lastError.txt");
	print "Failed to open current user certificate store\n"
else
	print "Local Machine Digital Certificates:\n"
	n = certStore.get_NumCertificates()
	for i in 0 .. n-1
		cert = certStore.GetCertificate(i)
		# Print the common name of the certificate.
		print "CN: " + cert.subjectCN + "\n"
	end	
end

