# file: CopyMail.rb

# Ruby script to read a POP3 mailbox leaving the email on the mail server.

require '../chilkat'

# Create an instance of the mailman object for reading POP3 email.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your POP3 server's hostname and login/password
mailman.put_MailHost("mail.chilkatsoft.com")
mailman.put_PopUsername("myLogin")
mailman.put_PopPassword("myPassword")

# Download all the email in the mailbox without removing the email.
bundle = mailman.CopyMail()
if bundle == nil
	# Failed to download email.
	mailman.SaveLastError("errorLog.txt")
else	
	# Save the entire email bundle as XML.
	bundle.SaveXml("emailBundle.xml")
	
	# Loop over each email, print the From address and Subject, and save
	# each email to a .eml (MIME message source) file.
	numMessages = bundle.get_MessageCount()

	subject = Chilkat::CkString.new()
	from = Chilkat::CkString.new()
	for i in 0..(numMessages-1)
		email = bundle.GetEmail(i)
		email.get_Subject(subject)
		email.get_From(from)
		print "From:    " + from.getUtf8() + "\n"
		print "Subject: " + subject.getUtf8() + "\n\n"
		
		emlFilename = "email_"+i.to_s()+".eml"
		email.SaveEml(emlFilename)
	end
end

