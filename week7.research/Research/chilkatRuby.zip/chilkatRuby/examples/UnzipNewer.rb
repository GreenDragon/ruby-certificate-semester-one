# file: UnzipNewer.rb

require '../chilkat'

# Unzip files that have a more recent last-modified date/timestamp
# than the corresponding file on disk.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

success = zip.OpenZip("exampleData.zip")
if success
	# Returns -1 if error, otherwise returns the number of files unzipped.
	
	# In this example, UnzipNewer will create the directory "unzipDir" in the current
	# working directory (if it does not already exist) and unzip into it.
	numUnzipped = zip.UnzipNewer("unzipDir")
	printf "numUnzipped = %d\n",numUnzipped
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end
