# file: UnzipStrongEncrypted.rb

require '../chilkat'

# Simple example showing how to unzip a 128-bit WinZip AES strong-encrypted .zip file.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

# Setting Encryption = 4 indicates an WinZip AES encrypted zip
zip.put_Encryption(4)
zip.put_EncryptKeyLength(128)
zip.SetPassword("secret")

# With WinZip AES Encryption, the zip can be opened even if the password
# is incorrect.  This is standard, and you'll find the same behavior with
# the WinZip program.
success = zip.OpenZip("strongEncrypted.zip")
if success
	# The zip in this example contains these files and directories:
	# exampleData\
	# exampleData\hamlet.xml
	# exampleData\123\
	# exampleData\aaa\
	# exampleData\123\hello.txt
	# exampleData\aaa\banner.gif
	# exampleData\aaa\dude.gif
	# exampleData\aaa\xyz\	
	
	# Returns -1 if error, otherwise returns the number of files and directories
	# unzipped.
	# In this example, Unzip will create the directory "unzipDir" in the current
	# working directory (if it does not already exist) and unzip into it.
	
	# If the password is incorrect, numUnzipped will return either -1 or the number
	# of files successfully unzipped.  Technically (but not likely) it is possible to
	# create a zip that contains some encrypted files and some unencrypted files.
	numUnzipped = zip.Unzip("unzipDir")
	printf "numUnzipped = %d\n",numUnzipped
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end
