# file: mimeEncodings.rb

require '../chilkat'

# Demonstrates how to use different content-transfer-encodings
# such as quoted-printable, base64, and 8bit.
mime = Chilkat::CkMime.new()
mime.UnlockComponent("anything for 30-day trial")

mime.put_Charset("iso-8859-1")
# Begin with 8bit.
mime.put_Encoding("8bit")
		
# Add some Danish text...
mime.SetBodyFromPlainText("Jeg kan spise glas, det g�r ikke ondt p� mig.")
		    		
print mime.mime() + "\n\n"
		    
#  This MIME is created:
# 		
# content-transfer-encoding: 8bit
# content-type: text/plain;
# 	 charset="iso-8859-1"
# 
# Jeg kan spise glas, det g�r ikke ondt p� mig.

		
# Change the encoding to base64:
mime.put_Encoding("base64")
print mime.mime() + "\n\n"
		
#  The MIME is now in base64 format:
# 		
# content-type: text/plain;
# 	 charset="iso-8859-1"
# content-transfer-encoding: base64
# 
# SmVnIGthbiBzcGlzZSBnbGFzLCBkZXQgZ/hyIGlra2Ugb25kdCBw5SBtaWcu

		
# Change the encoding to quoted-printable:
mime.put_Encoding("quoted-printable")
print mime.mime() + "\n\n"
		
#  The MIME is now in quoted-printable format:
# 		
# content-type: text/plain;
# 	 charset="iso-8859-1"
# content-transfer-encoding: quoted-printable
# 
# Jeg kan spise glas, det g=F8r ikke ondt p=E5 mig.


		
