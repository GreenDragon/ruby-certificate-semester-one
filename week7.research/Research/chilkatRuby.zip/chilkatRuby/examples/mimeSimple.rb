# file: mimeSimple.rb

require '../chilkat'

# Create a simple MIME message with a text body.
mime = Chilkat::CkMime.new()
mime.UnlockComponent("anything for 30-day trial")

# All MIME messages should include a content-type header field.
# The content-type header usually includes the charset attribute
# if the content type begins with "text/".
# MIME messages with text bodies should also include a content-transfer-encoding.

# The SetBodyFromPlainText sets the MIME body, but it also checks
# the content-type, charset, and content-transfer-encoding,
# and if not set they are initialized to "text/plain", "us-ascii", and "7bit".
mime.put_Charset("iso-8859-1")
mime.put_Encoding("quoted-printable")

# Add some Danish text to make it interesting:
mime.SetBodyFromPlainText("Jeg kan spise glas, det g�r ikke ondt p� mig.")

print mime.mime()

# We get this MIME:
#
# content-transfer-encoding: quoted-printable
# content-type: text/plain;
#     charset="iso-8859-1"
#
# Jeg kan spise glas, det g=F8r ikke ondt p=E5 mig.


