# file: SelfExtractExe3.rb

require '../chilkat'

# How to create a self-extracting executable in Ruby with options.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

# Calling NewZip does not actually create a file on disk.  The filename
# argument indicates the name of the zip file name to be created when
# WriteZip is called.  However, in this example, WriteExe is called instead,
# so the zip filename is meaningless.
zip.NewZip("notUsed.zip")
zip.AppendFiles("exampleData2/*",true)

# Set some options with respect to how the EXE will behave when run:

# Create a self-extracting EXE that has no user-interface, extracts
# to a temp directory, and automatically runs a setup.exe 
zip.put_AutoTemp(true)
zip.put_ExeNoInterface(true)

# Use a custom icon for the EXE:
zip.put_ExeIconFile("box.ico")

# After unzipping, run a program that was unzipped.
zip.put_AutoRun("exampleData2/setup.exe")
# Note: Sometimes people have trouble in determining the filepath to use
# for the AutoRun EXE.  A good way to determine it is to call zip.WriteZip to
# create the .zip file and then examine it with WinZip.  Use the filepath
# as listed by WinZip for the AutoRun EXE's filepath.

# Pass command line parameters to the AutoRun EXE:
zip.put_AutoRunParams("-a -b 123 -xyz")


# Write the self-extracting EXE
zip.WriteExe("example.exe")

