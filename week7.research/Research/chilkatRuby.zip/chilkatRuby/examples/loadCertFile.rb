# file: LoadCertFile.rb

require '../chilkat'

# How to load a .cer digital certificate and get information.
# The CkCert is a free utility class that can be used in any
# Ruby application/script without the need to purchase a license.
cert = Chilkat::CkCert.new()

success = cert.LoadFromFile("tagtooga.cer")
if not success
	cert.SaveLastError("lastError.txt");
else
	print "Subject Email: " + cert.subjectE + "\n"
	print "Subject Country: " + cert.subjectC + "\n"
	print "Subject State/Province: " + cert.subjectS + "\n"
	print "Subject City/Locality: " + cert.subjectL + "\n"
	print "Subject Organization/Company Name: " + cert.subjectO + "\n"
	print "Subject Organizational Unit: " + cert.subjectOU + "\n"
	print "Subject Common Name: " + cert.subjectCN + "\n"
	print "Subject Distinguished Name: " + cert.subjectDN + "\n"
	
	print "Issuer Email: " + cert.issuerE + "\n"
	print "Issuer Country: " + cert.issuerC + "\n"
	print "Issuer State/Province: " + cert.issuerS + "\n"
	print "Issuer City/Locality: " + cert.issuerL + "\n"
	print "Issuer Organization/Company Name: " + cert.issuerO + "\n"
	print "Issuer Organizational Unit: " + cert.issuerOU + "\n"
	print "Issuer Common Name: " + cert.issuerCN + "\n"
	print "Issuer Distinguished Name: " + cert.issuerDN + "\n"
	
	print "SHA1 Thumbprint: " + cert.sha1Thumbprint + "\n"
	print "RFC822 Name: " + cert.rfc822Name + "\n"
	print "Serial Number: " + cert.serialNumber + "\n"
	
	# Is the certificate's signature verified?
	if cert.get_SignatureVerified()
		print "Certificate signature verified\n"
	else
		print "Certificate signature not verified\n"
	end
	
	if cert.get_TrustedRoot()
		print "Certificate has a trusted root\n"
	else
		print "Certificate does not have a trusted root\n"
	end
	
	if cert.get_Revoked()
		print "Certificate has been revoked!\n"
	else
		print "Certificate NOT revoked\n"
	end
	
	if cert.get_Expired()
		print "Certificate is expired!\n"
	else
		print "Certificate NOT expired\n"
	end
	
	if cert.get_IsRoot()
		print "This is a root certificate\n"
	else
		print "This is NOT a root certificate\n"
	end
	
	if cert.HasPrivateKey()
		print "A private key is found and available\n"
	else
		print "A private key is NOT found or there is no permission to access\n"
	end
	
	if cert.get_ForTimeStamping()
		print "Intended use includes time stamping\n"
	else
		print "Intended use does not include time stamping\n"
	end
	
	if cert.get_ForCodeSigning()
		print "Intended use includes code signing\n"
	else
		print "Intended use does not include code signing\n"
	end
	
	if cert.get_ForClientAuthentication()
		print "Intended use includes client authentication\n"
	else
		print "Intended use does not include client authentication\n"
	end
	
	if cert.get_ForServerAuthentication()
		print "Intended use includes server authentication\n"
	else
		print "Intended use does not include server authentication\n"
	end
	
	if cert.get_ForSecureEmail()
		print "Intended use includes secure email\n"
	else
		print "Intended use does not include secure email\n"
	end
	
	sysTime0 = Chilkat::SYSTEMTIME.new()
	cert.get_ValidFrom(sysTime0)
	
	sysTime1 = Chilkat::SYSTEMTIME.new()
	cert.get_ValidTo(sysTime1)
	
	print "Valid from " + sysTime0.wMonth.to_s() + "/" + sysTime0.wDay.to_s() + "/" + sysTime0.wYear.to_s() + 
		" to " + sysTime1.wMonth.to_s() + "/" + sysTime1.wDay.to_s() + "/" + sysTime1.wYear.to_s()
		
end
