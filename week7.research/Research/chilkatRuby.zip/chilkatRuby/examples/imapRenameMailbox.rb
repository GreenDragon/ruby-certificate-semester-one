# file: imapRenameMailbox.rb

require '../chilkat'

# Ruby script to rename an IMAP mailbox.

imap = Chilkat::CkImap.new()
success = imap.UnlockComponent("anything for 30-day trial")
if not success
	print "imap component is locked!"
	exit
end

# Connect to the IMAP server
success = imap.Connect("mail.chilkatsoft.com")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Login to the IMAP server.
success = imap.Login("***", "***")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Rename a mailbox:
success = imap.RenameMailbox("INBOX.abc123", "INBOX.xyz789")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Logout
imap.Logout()

# Disconnect from the IMAP server.
imap.Disconnect()
