# file: SelfExtractExe.rb

require '../chilkat'

# How to create a self-extracting executable in Ruby.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

# Calling NewZip does not actually create a file on disk.  The filename
# argument indicates the name of the zip file name to be created when
# WriteZip is called.  However, in this example, WriteExe is called instead,
# so the zip filename is meaningless.
zip.NewZip("notUsed.zip")
zip.AppendFiles("exampleData/*",true)

# Write the self-extracting EXE
zip.WriteExe("example.exe")

