# file: exportCert.rb

require '../chilkat'

# How to export to a .cer file a digital certificate matching an email address in
# the Windows registry Current User Certificate Store.

# The CkCert, CkCertStore, and CkCreateCS are free utility classes that can be 
# used in any Ruby application/script without the need to purchase a license.

ccs = Chilkat::CkCreateCS.new()

# Open the current-user certificate store in read-only mode.
ccs.put_ReadOnly(true)
certStore = ccs.OpenCurrentUserStore()

if certStore == nil
	ccs.SaveLastError("lastError.txt");
	print "Failed to open current user certificate store\n"
else
	cert = certStore.FindCertBySubjectE("admin@tagtooga.com")
	if (cert == nil)
		print "Failed to find certificate matching admin@tagtooga.com\n"
	else
		# Print the distinguished name of the certificate.
		print "Exporting: " + cert.subjectDN + "\n"
		
		# Now export it to a .cer file.
		cert.SaveToFile("myCert.cer")
	end
end

