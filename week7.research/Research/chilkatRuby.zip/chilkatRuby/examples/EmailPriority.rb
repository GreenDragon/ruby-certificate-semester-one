# file: EmailPriority.rb

require '../chilkat'

# Demonstrates how to send high-priority e-mail
# Setting the priority of an email is simply a matter
# of setting the X-Priority header field.
# Values of 1 through 5 are acceptable, with 1 being the
# highest priority, 3 = normal, and 5 = lowest priority.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a authentication, set username/password
#mailman.put_SmtpUsername("***")
#mailman.put_SmtpPassword("***")

# Create an e-mail object
email = Chilkat::CkEmail.new()
# Set the email's priority to high:
email.AddHeaderField("X-Priority","1")

email.put_Subject("How to send high priority email in the Ruby programming language")
email.put_Body("High priority email sent from a Ruby script")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients...
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

# Send the email
success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
