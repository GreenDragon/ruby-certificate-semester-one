# file: xmlJapanese.rb
# 
# Demonstrates how to work with Japanese XML documents

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

# Some Chilkat XML Ruby examples utilize these online XML data samples:
# http://www.chilkatsoft.com/xml-samples/bookstore.xml
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
# http://www.chilkatsoft.com/xml-samples/pigs.xml
# http://www.chilkatsoft.com/xml-samples/plants.xml
# http://www.chilkatsoft.com/xml-samples/japanese.xml
# http://www.chilkatsoft.com/xml-samples/hamlet.xml
    
# This example works with japanese.xml
xml = Chilkat::CkXml.new()
xml.LoadXmlFile("japanese.xml")

# This source file is Shift_JIS encoded...
# Loop over nodes having this tag: �Ɩ���
strTag = Chilkat::CkString.new()
strTag.appendEnc("�Ɩ���","Shift_JIS")

# Indicate that string inputs should be utf-8
xml.put_Utf8(true)
strContent = Chilkat::CkString.new()
node = xml.SearchForTag(nil,strTag.getUtf8())
while (node != nil) 
	node.get_Content(strContent)
	# Redirect this output to a file.  DOS windows do not display utf-8 correctly.
	printf "%s: %s\n",strTag.getUtf8(),strContent.getUtf8()
	node = xml.SearchForTag(node,strTag.getUtf8())
end


