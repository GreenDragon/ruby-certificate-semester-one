# file: EmailReturnReceipt.rb

require '../chilkat'

# Request a return-receipt when sending email.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a authentication, set username/password
#mailman.put_SmtpUsername("***")
#mailman.put_SmtpPassword("***")

# Create an e-mail object
email = Chilkat::CkEmail.new()
email.put_Subject("Send email with return-receipt requested in Ruby")
email.put_Body("Email with return-receipt requested sent from a Ruby script")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients...
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

# The disposition-notification-to email header field
# is what should be set to requeset a return-receipt.
# Information about numerous email header fields can be found
# at this URL: http://chilkatsoft.com/braindump/email_headers.html
# The Chilkat email component uses a ReturnReceipt property, which
# if set to true causes the disposition-notification-to header
# to be added to an email.
email.put_ReturnReceipt(true)

# An alternative way of doing the same thing is to do this:
# email.AddHeaderField("Disposition-Notification-To","<support@chilkatsoft.com>")

# Send the email
success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
