# file: xmlChildIterate.rb
# 
# Iterate over child nodes in a document using FirstChild/NextSibling.

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

# The Chilkat XML Ruby examples utilize these online XML data samples:
# http://www.chilkatsoft.com/xml-samples/bookstore.xml
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
# http://www.chilkatsoft.com/xml-samples/pigs.xml
# http://www.chilkatsoft.com/xml-samples/plants.xml
# http://www.chilkatsoft.com/xml-samples/japanese.xml
# http://www.chilkatsoft.com/xml-samples/hamlet.xml
    
xml = Chilkat::CkXml.new()
xml.LoadXmlFile("plants.xml")

# Iterate over each "PLANT" under the "CATALOG" node.
# (The CATALOG node is the root node of the document...)
commonName = Chilkat::CkString.new()

plant = xml.FirstChild()
while plant != nil
	plant.GetChildContent("COMMON",commonName)
	print commonName.getString() + "\n"
	plant = plant.NextSibling()
end

