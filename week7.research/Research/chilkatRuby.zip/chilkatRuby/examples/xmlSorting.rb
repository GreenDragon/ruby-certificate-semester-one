# file: xmlSorting.rb
# 
# Demonstrates how to sort parts of an XML document.

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

# Some Chilkat XML Ruby examples utilize these online XML data samples:
# http://www.chilkatsoft.com/xml-samples/bookstore.xml
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
# http://www.chilkatsoft.com/xml-samples/pigs.xml
# http://www.chilkatsoft.com/xml-samples/plants.xml
# http://www.chilkatsoft.com/xml-samples/japanese.xml
# http://www.chilkatsoft.com/xml-samples/hamlet.xml
    
# Create some string objects we'll need later...
tagStr = Chilkat::CkString.new()
contentStr = Chilkat::CkString.new()
xmlStr = Chilkat::CkString.new()
    
# Create a new XML document
xml = Chilkat::CkXml.new()

# Load nutrition.xml, which is available here: 
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
xml.LoadXmlFile("nutrition.xml")

# Navigate to the first "food" child
foodNode = xml.FindChild("food")
# 1 = ascending, 0 = descending
ascending = 1
foodNode.SortByTag(ascending)

# Print the XML sub-tree rooted at foodNode.
# The children are sorted by tag.
n = foodNode.get_NumChildren()
for i in 0 .. n-1
	foodNode.GetChildTag(i,tagStr)
	printf "%s\n",tagStr.getString()
end

# Sorting is case sensitive by default.  To switch any sorting
# to case insensitive, set the SortCaseInsensitive property = true
# on the XML node where the sort method is called.
# For example:
foodNode.put_SortCaseInsensitive(true)


# The children of a node can be sorted by content.
# This example creates a new document and sorts the children
# by content:
xml2 = Chilkat::CkXml.new()
xml2.put_Tag("companies")
xml2.NewChild2("company","microsoft")
xml2.NewChild2("company","boeing")
xml2.NewChild2("company","starbucks")
xml2.NewChild2("company","apple")
xml2.NewChild2("company","google")
xml2.NewChild2("company","chilkat")
xml2.NewChild2("company","yahoo")
xml2.NewChild2("company","intel")
xml2.SortByContent(ascending)

xml2.GetXml(xmlStr)
printf "%s\n",xmlStr.getString()

# Prints:
# <companies>
# <company>apple</company>
# <company>boeing</company>
# <company>chilkat</company>
# <company>google</company>
# <company>intel</company>
# <company>microsoft</company>
# <company>starbucks</company>
# <company>yahoo</company>
# </companies>


# The SortRecordsByContent method is useful for sorting XML records.
# This example uses pigs.xml, found at:
# http://www.chilkatsoft.com/xml-samples/pigs.xml
xml3 = Chilkat::CkXml.new()
xml3.LoadXmlFile("pigs.xml")
# Sort the records by the name field:
xml3.SortRecordsByContent("name",ascending)
xml3.SaveXml("pigsSortedByName.xml")

# Records can also be sorted by attribute values.
# As an example, if each "name" node in a pig's record included
# an "id" attribute, the pig records could by sorted by "id" as follows:
xml3.SortRecordsByAttribute("name","id",ascending)
# The first argument of SortRecordsByAttribute is the tag (i.e. field name)
# and the 2nd argument is the attribute name.



# Direct children can also be sorted by attribute.  For example:
xml4 = Chilkat::CkXml.new()
xml4.put_Tag("companies")
childNode = xml4.NewChild("company","microsoft")
childNode.AddAttribute("state","WA")
childNode = xml4.NewChild("company","boeing")
childNode.AddAttribute("state","IL")
childNode = xml4.NewChild("company","starbucks")
childNode.AddAttribute("state","WA")
childNode = xml4.NewChild("company","apple")
childNode.AddAttribute("state","CA")
childNode = xml4.NewChild("company","google")
childNode.AddAttribute("state","CA")
childNode = xml4.NewChild("company","chilkat")
childNode.AddAttribute("state","IL")
childNode = xml4.NewChild("company","yahoo")
childNode.AddAttribute("state","CA")
childNode = xml4.NewChild("company","intel")
childNode.AddAttribute("state","WA")
xml4.SortByAttribute("state",ascending)
xml4.GetXml(xmlStr)
printf "%s\n",xmlStr.getString()

# Prints:
# <companies>
# <company state="CA">google</company>
# <company state="CA">apple</company>
# <company state="CA">yahoo</company>
# <company state="IL">chilkat</company>
# <company state="IL">boeing</company>
# <company state="WA">starbucks</company>
# <company state="WA">intel</company>
# <company state="WA">microsoft</company>
# </companies>