# file: EmailWebPage.rb

# Ruby script to convert a Web page (URL) into HTML email and send.

# Downloads a web page and all embedded images and CSS style
# sheets into a CkEmail object.
# The web page converted to email is: 
# http://www.chilkatsoft.com/testEmail/testEmail.html

require '../chilkat'

mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a login, set username/password
# mailman.put_SmtpUsername("myUsername")
# mailman.put_SmtpPassword("myPassword")

# The Chilkat MHT object is needed to convert a URL to an HTML email.
mht = Chilkat::CkMht.new()
mht.UnlockComponent("anything for 30-day trial")

# Create the HTML mail
email = mht.GetEmail("http://www.chilkatsoft.com/testEmail/testEmail.html")

# Don't forget the subject and From/To ..
email.put_Subject("Sending Web page from Ruby")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

# Send the HTML e-mail...
success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
